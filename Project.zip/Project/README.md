# Project
Steps
+ Download xampp server bundle
+ open on browser 'localhost/phpmyadmin'
+ create a new database named 'Users'
+ then click on import button and select the newdb.sql file that is already uploaded in repository
+ copy and paste all files from the repository to htdocs folder(if you're not sure where it is google)
+ now open the xamp application and start the mysql and apache server.
Now you're good to go
if youre not sure how to set this up check any tutorial on php.
